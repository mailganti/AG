import os
from fastapi import Header, HTTPException, Depends
from typing import List, Optional

# You need to import get_db since require_role uses it for validation
# Assuming this path based on your other files
from controller.db.db import get_db 

ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN")

# ========================================================
# 1. Original Admin Token Check (Used for /agents, /scripts, /tokens)
# ========================================================

def require_admin(x_admin_token: str = Header(..., alias="X-ADMIN-TOKEN")):
    """
    Requires the X-ADMIN-TOKEN header to match the ADMIN_TOKEN environment variable.
    """
    if ADMIN_TOKEN is None:
        raise HTTPException(status_code=500, detail="ADMIN_TOKEN not configured")
    if x_admin_token != ADMIN_TOKEN:
        raise HTTPException(status_code=401, detail="invalid_admin_token")
    return True

# ========================================================
# 2. Role-Based Token Check (Used for /workflows)
# ========================================================

def require_role(roles: List[str]):
    """
    Dependency that validates X-ADMIN-TOKEN against the DB for a specific role
    and returns the actor (token user ID/name).
    """
    # FIX: Ensure it looks for "X-ADMIN-TOKEN" to match client-side JS
    def wrapper(x_token: Optional[str] = Header(None, alias="X-ADMIN-TOKEN")) -> str:
        if x_token is None:
            raise HTTPException(status_code=401, detail="X-ADMIN-TOKEN header missing")

        db = get_db()
        # Assuming db.validate_token returns the actor ID/name if valid
        actor = db.validate_token(x_token, required_roles=roles)
        
        if not actor:
            raise HTTPException(status_code=401, detail="invalid token or insufficient role")
        
        return actor
    return wrapper

# Helper function to use the dependency in route signatures
def require_role_actor(roles: List[str]):
    """Returns a dependency that injects the validated actor's ID/name."""
    return Depends(require_role(roles))