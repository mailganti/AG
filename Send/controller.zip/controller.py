#!/usr/bin/env python3
from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import os

# 1. Imports from controller (Keep this)
from controller.api.agents import router as agents_router
from controller.api.workflows import router as workflows_router
from controller.api.scripts import router as scripts_router
from controller.api.tokens import router as tokens_router

# 2. Environment variable (Keep this)
ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN")

# 3. App initialization
app = FastAPI(title="Orchestration Controller Testing", redirect_slashes=True)

# 4. Directory Setup
BASE_DIR = os.path.dirname(__file__)
# Correct path to UI directory (assuming it's relative to this file)
UI_DIR = os.path.join(BASE_DIR, "ui")

print(">>> Serving UI from:", UI_DIR)

# 5. API Router Inclusion (This is the corrected section)
# NOTE: Only include them once, with the correct prefix.
app.include_router(agents_router, prefix="/api/agents", tags=["agents"])
app.include_router(workflows_router, prefix="/api/workflows", tags=["workflows"])
app.include_router(scripts_router, prefix="/api/scripts", tags=["scripts"])
app.include_router(tokens_router, prefix="/api/tokens", tags=["tokens"])

# 6. CORS Middleware (Keep this)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- UI and Health Routes ---

# 7. Serve the UI's static assets (CSS, JS, images) from a dedicated path.
# Change the mount point from "/" to "/static" or "/ui/static"
app.mount("/ui", StaticFiles(directory=UI_DIR), name="ui") 


# 8. Define a proper root route that serves the main HTML file.
@app.get("/")
def serve_index():
    # Assuming your main entry file is index.html
    return FileResponse(os.path.join(UI_DIR, "index.html"))

# 9. Serve the specific register agent page
# This now works because the StaticFiles mount is on /ui and this is specific.
@app.get("/register_agent")
def serve_register_agent():
    # Adjust path to be relative to UI_DIR
    ui_path = os.path.join(UI_DIR, "register_agent.html")
    return FileResponse(ui_path)

# 10. Health check (Keep this)
@app.get("/healthz")
def healthz():
    return {"status": "ok"}